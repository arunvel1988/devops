#!/bin/bash

check_and_kill_port() {
  local port=$1
  # Check if the port is in use
  if lsof -i:$port > /dev/null; then
    echo "Port $port is in use. Killing the process occupying it..."
    lsof -ti:$port | xargs kill -9
    echo "Process on port $port has been terminated."
  else
    echo "Port $port is free."
  fi
}

run_command() {
  case $1 in
    1)
      echo "Running 'kubectl port-forward svc/guestbook-ui 8010:8010 --address 0.0.0.0'"
      check_and_kill_port 8010
      kubectl port-forward svc/guestbook-ui 8010:8010 --address 0.0.0.0
      ;;
    2)
      echo "Running 'kubectl port-forward svc/el-clone-build-push-event-listener 8080:8080 --address 0.0.0.0'"
      check_and_kill_port 8080
      kubectl port-forward svc/el-clone-build-push-event-listener 8080:8080 --address 0.0.0.0
      ;;
    *)
      echo "Invalid choice. Please select 1 or 2."
      ;;
  esac
}

echo "Choose an option:"
echo "1. Run 'kubectl port-forward svc/guestbook-ui 8010:8010 --address 0.0.0.0'"
echo "2. Run 'kubectl port-forward svc/el-clone-build-push-event-listener 8080:8080 --address 0.0.0.0'"
read -p "Enter your choice (1 or 2): " choice

run_command $choice
