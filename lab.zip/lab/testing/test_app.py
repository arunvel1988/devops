import unittest
from app import app  # Assuming your Flask app is in a file named `app.py`

class FlaskAppTest(unittest.TestCase):

    def setUp(self):
        """Set up the Flask test client before each test."""
        self.app = app.test_client()  # Flask's test client
        self.app.testing = True  # Enables error propagation

    def test_hello_world(self):
        """Test the '/ ' route to check if it returns the expected response."""
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)  # Check for a 200 OK status
        self.assertEqual(response.data, b'Hello, World!')  # Check for correct response message

if __name__ == '__main__':
    unittest.main()
